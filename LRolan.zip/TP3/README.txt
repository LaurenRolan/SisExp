/* Author: Lauren Sampaio
 * File: README.txt
 */

--Pour executer le logiciel:
	make
	./fsieve
	

--Pour supprimer les .o et l'executable:
	make clean

