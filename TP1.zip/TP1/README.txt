/* Author: Lauren Sampaio
 * File: README.txt
 */

--Pour executer le logiciel:
	make
	./iplot

--Pour supprimer les .o et l'executable:
	make clean

