/* Author: Lauren Sampaio
 * File: iplot.h
 */


/* Fonction pour récrire le fichier <<commande.gp>> 
avec le nombre <<borne>> */
void writeCommand(int b);