/* Author: Lauren Sampaio
 * File: sin_cos.h
 */

void sinus(int pid, double angle);

void cosinus(int pid, double angle);