/* Author: Lauren Sampaio
 * File: README.txt
 */

--Pour executer le logiciel:
	make
	./sin_cos_g
	

--Pour supprimer les .o et l'executable:
	make clean

