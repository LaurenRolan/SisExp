/* Author: Lauren Sampaio
 * File: sin_cos_g.h
 */

void sinus(double angle);

void cosinus(double angle);